<?php

$currentPage = 'turkey';

$title = "Turkey";

$keywords = "";

$description = "";

include("head.php");

?>

<?php include("header.php"); ?>



      <!--=====pages hero start=======-->

      <div class="page-hero-area _relative" style="background-image: url(assets/img/bg/page-bg.png);">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 m-auto text-center">
                    <div class="page-hero-hadding">
                        <h1>Turkey</h1>
                        <div class="space16"></div>
                        <div class="page-hero-p">
                            <a href="index.php">Home</a>
                            <span><i class="fa-solid fa-angle-right"></i></span>
                            <p>Turkey</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <img class="page-hero-element1 aniamtion-key-2" src="assets/img/shapes/page-header-element1.svg" alt="">
        <img class="page-hero-element2 aniamtion-key-3" src="assets/img/shapes/page-header-element2.svg" alt="">
        <img class="page-hero-element3 aniamtion-key-1" src="assets/img/shapes/page-header-element1.svg" alt="">
        <img class="page-hero-element4 aniamtion-key-2" src="assets/img/shapes/page-header-element2.svg" alt="">
      </div>

      <!--=====pages hero end=======-->
<!--=====service details start=======-->
<!--=====service details start=======-->

<div class="service-details-all sp3">
  <div class="container">
      <div class="row">
          <div class="col-lg-8 m-auto">
              <div class="sidebar-all-content">
                  <article>
                      <div class="img5 img100">
                          <img src="assets/img/image/turkey 2.jpg" alt="">
                      </div>
                      <div class="space24"></div>
                      <div class="hadding2">
                          <h1>Turkey</h1>
                          <div class="space16"></div>
                          <p>There are various types of visas available for Turkey, including tourist e-Visas, work permits, student visas, and residence permits for purposes such as family reunification, employment, or investment through the Citizenship by Investment Program. It is important to identify the visa category that best suits your travel intentions.</p>
                          <div class="space16"></div>
                          <p>
                          The Directorate General of Migration Management (DGMM) and Turkish diplomatic missions abroad handle visa and residence permit applications. Therefore, it is advisable to visit the official Republic of Turkey e-Visa portal or contact the nearest Turkish diplomatic mission for accurate information. Since immigration regulations can change over time, staying informed through official sources is crucial.</p>
                      </div>
                  </article>
                  <div class="space20"></div>
                  <article>
                      <div class="row">
                          <div class="col-lg-12">
                              <div class="space30"></div>
                              <div class="hadding2">
                                  <h3><a href="countries-details.html">Schedule a Visa Interview</a></h3>
                                  <div class="space16"></div>
                                    <p class="lead mb-4">
              After identifying the appropriate visa category and gathering all required documents, your next step is to arrange an appointment with the Turkish embassy or consulate. For many visitors, the e-Visa system eliminates the need for an in-person interview. Here's how you can proceed:
          </p>
          
          <ul class="list-unstyled">
              <li class="mb-3 pb-2 border-bottom">
                  <i class="fa-solid fa-plane"></i>
                  <span class="fw-bold">Find Your Local Consulate or Embassy:</span>
                  Visit the official website of the Turkish diplomatic mission in your area to learn about the specific application procedures for visas that cannot be obtained online.
              </li>
              <li class="mb-3 pb-2 border-bottom">
                  <i class="fa-solid fa-plane"></i>
                  <span class="fw-bold">Check e-Visa Eligibility:</span>
                  Many nationalities can apply for an e-Visa online through the official Turkish government e-Visa website. Check if your nationality qualifies for this simplified process.
              </li>
              <li class="mb-3 pb-2 border-bottom">
                  <i class="fa-solid fa-plane"></i>
                  <span class="fw-bold">Book Your Appointment:</span>
                  For visas requiring in-person applications, contact the diplomatic mission to secure an appointment slot. Since available appointments can be limited, it is advisable to reach out as early as possible.
              </li>
              <li class="mb-3 pb-2 border-bottom">
                  <i class="fa-solid fa-plane"></i>
                  <span class="fw-bold">Prepare Required Documents:</span>
                  Organize all your supporting documents—such as proof of financial means, travel itinerary, accommodation details, and any other required evidence—to ensure you are well-prepared for document submission.
              </li>
              <li class="mb-3">
                  <i class="fa-solid fa-plane"></i>
                  <span class="fw-bold">Stay Informed:</span>
                  Immigration policies and procedures may change, so it's important to regularly check with the diplomatic mission or the official e-Visa website for any updates regarding the visa application process.
              </li>
          </ul>
</div>
                          </div>

                          <div class="col-lg-12">
                              <div class="space30"></div>
                              <div class="hadding2">
                                  <h3><a href="countries-details.html">Visa Processing</a></h3>
                                  <div class="space16"></div>
                                  <p>After completing the visa application form and paying the required fee, you can submit your application online (for e-Visas) or to the Turkish embassy or consulate in your home country. Processing times and requirements vary depending on the type of visa you are applying for.</p>
                                   
          
          <ul class="list-unstyled">
              <li class="mb-3 pb-2 border-bottom">
                  <i class="fa-solid fa-plane"></i>
                  <span class="fw-bold">e-Visa for Tourists:</span>
                  Many nationalities can obtain an e-Visa online, which is typically processed within 24-72 hours. The e-Visa is usually valid for multiple entries over 180 days with stays of up to 90 days. The application process is straightforward and can be completed entirely online.
              </li>
              <li class="mb-3 pb-2 border-bottom">
                 <i class="fa-solid fa-plane"></i>
                  <span class="fw-bold">Residence Permit Requirements:</span>
                  For stays exceeding 90 days, foreign nationals must apply for a residence permit through the Directorate General of Migration Management. Applications are submitted online through the e-ikamet system and followed by an in-person appointment at the local DGMM office within 90 days of arrival.
              </li>
              <li class="mb-3 pb-2 border-bottom">
                  <i class="fa-solid fa-plane"></i>
                  <span class="fw-bold">Financial Guarantees:</span>
                  Turkey requires proof of sufficient funds for your stay - typically evidence of at least $50 per day for tourists. For residence permits, evidence of regular income, bank statements, or sponsorship may be required. For the Citizenship by Investment Program, a minimum real estate investment of $400,000 or a capital investment of $500,000 is required.
              </li>
              <li class="mb-3 pb-2 border-bottom">
                <i class="fa-solid fa-plane"></i>
                  <span class="fw-bold">Healthcare Requirements:</span>
                  All applicants for residence permits must obtain Turkish health insurance that meets government requirements. Short-term visitors are strongly advised to have travel health insurance. For longer stays, enrollment in the Turkish Social Security System (SGK) may be required.
              </li>
              <li class="mb-3">
               <i class="fa-solid fa-plane"></i>
                  <span class="fw-bold">Processing Timeframes:</span>
                  E-Visas are typically processed within 24-72 hours. Standard visa applications at consulates generally take 3-10 working days. Short-term residence permits take approximately 2-4 weeks, while work permits can take 30-90 days to process. Citizenship by Investment applications typically require 3-6 months for completion.
              </li>
          </ul>
                              </div>
                              
                          </div>

                          
                </div>
              </div>

              
          </div>

      </div>
  </div>
</div>

<!--=====service details end=======-->





<?php include("footer.php"); ?>

<!--=====contact end=======-->
<!--=====JS=======-->
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/fontawesome.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script src="assets/js/aos.js"></script>
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
  integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="assets/js/slick-slider.js"></script>
<script src="assets/js/mobile-menu.js"></script>
<script src="assets/js/tilt.jquery.js"></script>
<script src="assets/js/jquery.countup.js"></script>
<script src="assets/js/jquery.nice-select.js"></script>
<script src="assets/js/jquery.lineProgressbar.js"></script>
<script src="assets/js/mobile-meanmenu.js"></script>
<script src="assets/js/jquery.magnific-popup.min.js"></script>
<!-- <script src="assets/js/modal-video.min.js"></script> -->
<!-- <script src="assets/js/jquery.fittext.js"></script>
        <script src="assets/js/jquery.lettering.js"></script>
        <script src="assets/js/jquery.textillate.js"></script> -->
<script src="assets/js/main.js"></script>